---
title: $eventData
description: $eventData will return event data.
id: eventData
---

`$eventData` will return event data.

## Usage

```php
$eventData
```
