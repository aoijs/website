---
title: $error
description: $error will return information about the error.
id: error
---

`$error` will return information about the error, used in `onFunctionError` commands.

## Usage

```php
$error
```
