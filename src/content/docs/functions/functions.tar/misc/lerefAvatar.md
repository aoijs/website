---
title: $lerefAvatar
description: $lerefAvatar will return the Avatar of the creator of aoi.js
id: lerefAvatar
---

`$lerefAvatar` will return the Avatar of the creator of aoi.js

## Usage

```php
$lerefAvatar
```

## Example(s)

This will return the creator's Avatar:

```javascript
client.command({
  name: "lerefAvatar",
  code: `
    $lerefAvatar
    `
});
```
