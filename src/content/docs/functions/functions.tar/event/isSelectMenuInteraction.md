---
title: $isSelectMenuInteraction
description: $isSelectMenuInteraction will return either true or false depending on the type of the interaction.
id: isSelectMenuInteraction
---

`$isSelectMenuInteraction` will return either true or false depending on the type of interaction.

## Usage

```php
$isSelectMenuInteraction
```
