---
title: $isComponentInteraction
description: $isComponentInteraction will return either true or false depending on the type of the interaction.
id: isComponentInteraction
---

`$isComponentInteraction` will return either true or false depending on the type of interaction.

## Usage

```php
$isComponentInteraction
```
