---
title: $isContextMenuInteraction
description: $isContextMenuInteraction will return either true or false depending on the type of the interaction.
id: isContextMenuInteraction
---

`$isContextMenuInteraction` will return either true or false depending on the type of interaction.

## Usage

```php
$isContextMenuInteraction
```
