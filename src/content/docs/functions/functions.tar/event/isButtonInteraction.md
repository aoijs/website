---
title: $isButtonInteraction
description: $isButtonInteraction will return either true or false depending on the type of the interaction.
id: isButtonInteraction
---

`$isButtonInteraction` will return either true or false depending on the type of interaction.

## Usage

```php
$isButtonInteraction
```
