---
title: $isCommandInteraction
description: $isCommandInteraction will return either true or false depending on the type of the interaction.
id: isCommandInteraction
---

`$isCommandInteraction` will return either true or false depending on the type of interaction.

## Usage

```php
$isCommandInteraction
```
