---
title: $oldMessage
description: $oldMessage holds the content of the message before it was updated. (if any)
id: oldMessage
---

`$oldMessage` holds the content of the message before it was updated. (if any)

## Usage

```php
$oldMessage
```
