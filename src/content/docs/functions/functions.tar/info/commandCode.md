---
title: $commandCode
description: $commandCode will return the commands' code.
id: commandCode
---

`$commandCode` will return the commands' code.

## Usage

```php
$commandCode
```
