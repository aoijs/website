---
title: $commandName
description: $commandName will return the commands' name.
id: commandName
---

`$commandName` will return the commands' name.

## Usage

```php
$commandName
```
