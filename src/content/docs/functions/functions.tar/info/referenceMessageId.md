---
title: $referenceMessageId
description: $referenceMessageId will return the message ID of the message where the user replied to.
id: referenceMessageId
---

`$referenceMessageId` will return the message ID of the message where the user replied to.

## Usage

```php
$referenceMessageId
```
