---
title: $referenceGuildId
description: $referenceGuildId will return the guild ID of where the user replied in.
id: referenceGuildId
---

`$referenceGuildId` will return the guild ID of where the user replied in.

## Usage

```php
$referenceGuildId
```
