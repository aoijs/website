---
title: $referenceChannelId
description: $referenceChannelId will return the channel ID of where the user replied in.
id: referenceChannelId
---

`$referenceChannelId` will return the channel ID of where the user replied in.

## Usage

```php
$referenceChannelId
```
